"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const core_1 = __importDefault(require("@middy/core"));
const saveBrand_1 = require("../services/saveBrand");
const createBrand = async (event, context) => {
    const { brandName } = event.body;
    let brandRegstermodel = JSON.parse(event.body);
    console.info("Request Event", event);
    console.info("Request Body", event.body);
    const BrandId = "BR" + new Date().getTime().toString();
    const UserId = "U" + new Date().getTime().toString();
    const now = new Date();
    const endDate = new Date();
    endDate.setHours(now.getHours() + 1);
    const brandRequest = {
        BrandId: BrandId,
        UserID: UserId,
        Category: brandRegstermodel.Category,
        MobileNumber: brandRegstermodel.PhoneNumber,
        CreatedAt: now.toISOString(),
        UpdatedAt: now.toISOString(),
        Status: "Active"
    };
    let response = await (0, saveBrand_1.SaveBrand)(brandRequest);
    return {
        statusCode: 200,
        body: JSON.stringify(response),
    };
};
exports.handler = (0, core_1.default)(createBrand);
//# sourceMappingURL=createBrand.js.map