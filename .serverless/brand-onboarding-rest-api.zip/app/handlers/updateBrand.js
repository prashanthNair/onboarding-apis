"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const core_1 = __importDefault(require("@middy/core"));
const editBrand_1 = require("../services/editBrand");
const constants_1 = require("../utils/constants");
const updateBrand = async (event, context) => {
    let brandUpdateModel = JSON.parse(event.body);
    const now = new Date().toISOString();
    const brandrequest = {
        TableName: constants_1.BrandTable,
        Key: {
            BrandId: brandUpdateModel.BrandId,
            Category: brandUpdateModel.Category,
        },
        ExpressionAttributeNames: {
            "#MobileNumber": "MobileNumber",
        },
        ExpressionAttributeValues: {
            ":MobileNumber": brandUpdateModel.MobileNumber,
        },
        UpdateExpression: "SET #MobileNumber = :MobileNumber",
        ReturnValues: "ALL_NEW",
    };
    let response = await (0, editBrand_1.editBrand)(brandrequest);
    return {
        statusCode: 200,
        body: JSON.stringify(response),
    };
};
exports.handler = (0, core_1.default)(updateBrand);
//# sourceMappingURL=updateBrand.js.map