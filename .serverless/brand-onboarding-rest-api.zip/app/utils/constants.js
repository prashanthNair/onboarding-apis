"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BrandTable = void 0;
exports.BrandTable = "Brand-dev";
//# sourceMappingURL=constants.js.map