"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.editBrand = void 0;
const config_1 = require("../utils/config");
const constants_1 = require("../utils/constants");
const http_errors_1 = __importDefault(require("http-errors"));
const editBrand = async (brandRequest) => {
    try {
        let strBody = JSON.stringify(brandRequest);
        console.info(`Edit Brand Begins: String request - ${strBody}`);
        console.info(`Edit Brand Begins: Service Table - ${constants_1.BrandTable}'-'${brandRequest.BrandId}`);
        await config_1.documentClient.update(brandRequest)
            .promise();
        console.info("Edit Brand Service End:", brandRequest);
    }
    catch (error) {
        console.error(error);
        throw new http_errors_1.default.InternalServerError(error);
    }
    return {
        statusCode: 200,
        body: JSON.stringify(brandRequest),
    };
};
exports.editBrand = editBrand;
//# sourceMappingURL=editBrand.js.map